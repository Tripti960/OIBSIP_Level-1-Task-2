const menuIcon = document.querySelector('#menu-icon');
const navLinks = document.querySelector('.nav-links');

menuIcon.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Close the mobile menu after a link is tapped
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

// Contact popup: open on "Contact" button click, close on X or overlay click
const contactTrigger = document.querySelector('#contact-trigger');
const contactOverlay = document.querySelector('#contact-modal-overlay');
const contactClose = document.querySelector('#contact-modal-close');

if (contactTrigger && contactOverlay) {
    contactTrigger.addEventListener('click', () => {
        contactOverlay.classList.add('active');
    });

    contactClose.addEventListener('click', () => {
        contactOverlay.classList.remove('active');
    });

    contactOverlay.addEventListener('click', (e) => {
        if (e.target === contactOverlay) {
            contactOverlay.classList.remove('active');
        }
    });
}

// Contact form: submit to Netlify without a page reload
const contactForm = document.querySelector('.contact-form');
const formStatus = document.querySelector('#form-status');

if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const data = new FormData(contactForm);

        fetch('/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(data).toString()
        })
            .then(() => {
                formStatus.textContent = "Thanks! Your message has been sent.";
                contactForm.reset();
            })
            .catch(() => {
                formStatus.textContent = "Something went wrong. Please try again.";
            });
    });
}